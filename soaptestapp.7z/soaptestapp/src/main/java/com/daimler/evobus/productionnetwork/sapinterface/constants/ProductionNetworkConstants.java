package com.daimler.evobus.productionnetwork.sapinterface.constants;

public class ProductionNetworkConstants {

	public static final String FG_WORKPLACE_MANNHEIM = "S9";
    public static final String FG_WORKPLACE_ULM = "8901";
    public static final String FG_WORKPLACE_LIGNY = "T7";
    
    public static final String FG_PLANTCODE_MANNHEIM = "0028";
    public static final String FG_PLANTCODE_ULM = "0010";
    public static final String FG_PLANTCODE_LIGNY = "0062";
    
    public static final String DEV_URI = "https://aedjscs.bus.corpintra.net/XISOAPAdapter/MessageServlet?senderParty=&senderService=Dashboard&receiverParty=&receiverService=&interface=Z_ZPMONT_ZPRUECK1_O&interfaceNamespace=http://po.evobus.com/umlaufbestand";
    public static final String QA_URI = "https://aeqjscs.bus.corpintra.net:443/XISOAPAdapter/MessageServlet?senderParty=&senderService=Dashboard&receiverParty=&receiverService=&interface=Z_ZPMONT_ZPRUECK1_O&interfaceNamespace=http://po.evobus.com/umlaufbestand";
    public static final String PRD_URI = "https://aepjscs.bus.corpintra.net:443/XISOAPAdapter/MessageServlet?senderParty=&senderService=Dashboard&receiverParty=&receiverService=&interface=Z_ZPMONT_ZPRUECK1_O&interfaceNamespace=http://po.evobus.com/umlaufbestand";
}
