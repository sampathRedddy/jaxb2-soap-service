package com.daimler.evobus.productionnetwork.sapinterface.service;

import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;


@Service
public class SoapConnectorService extends WebServiceGatewaySupport {

	public Object callWebService(String url, Object request){
		
		return getWebServiceTemplate().marshalSendAndReceive(url, request);
	}
}
