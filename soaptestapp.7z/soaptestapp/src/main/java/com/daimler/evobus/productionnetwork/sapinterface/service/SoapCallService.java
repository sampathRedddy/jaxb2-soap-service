package com.daimler.evobus.productionnetwork.sapinterface.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.daimler.evobus.productionnetwork.sapinterface.fgwsdlmodel.ZAEMSDATUMRANGE;
import com.daimler.evobus.productionnetwork.sapinterface.fgwsdlmodel.ZZPMONTZPRUECK1RFC;
import com.daimler.evobus.productionnetwork.sapinterface.fgwsdlmodel.ZZPMONTZPRUECK1RFC.IMSODATUM;
import com.daimler.evobus.productionnetwork.sapinterface.mapper.BusMapper;
import com.daimler.evobus.productionnetwork.sapinterface.model.Bus;
import com.daimler.evobus.productionnetwork.sapinterface.fgwsdlmodel.ZZPMONTZPRUECK1RFCResponse;

import static com.daimler.evobus.productionnetwork.sapinterface.constants.ProductionNetworkConstants.*;


@Service
public class SoapCallService {

	@Autowired
	private SoapConnectorService soapConnector;
	
	@Autowired
    private BusMapper busMapper;
	
	
	@Scheduled(fixedRate = 60000)
	public void currentDayFGCount() throws ParseException {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Timestamp finishedDateTime = new Timestamp(System.currentTimeMillis());
        String finishedDate = sdf.format(finishedDateTime);
		
		ZAEMSDATUMRANGE dateRange = new ZAEMSDATUMRANGE();
		
		dateRange.setLOW(finishedDate);
		
		String devMnARBPL = "MHM1";
		String devMnWERKS = "0028";
		
		IMSODATUM dateValue = new IMSODATUM();
		dateValue.getItem().add(dateRange);
		
		Map<String, String[]> charPosition = new HashMap<String, String[]>();
		
		charPosition.put("MANNHEIM", new String [] { FG_WORKPLACE_MANNHEIM, FG_PLANTCODE_MANNHEIM });
//		charPosition.put("NEU-ULM", new String [] { FG_WORKPLACE_ULM, FG_PLANTCODE_ULM });
//		charPosition.put("LIGNY", new String [] { FG_WORKPLACE_LIGNY, FG_PLANTCODE_LIGNY });
		
		Set<String> plantDetails = charPosition.keySet();
		for(String plant : plantDetails) {
			
			String workplaceCode = charPosition.get(plant)[0];
			String plantCode = charPosition.get(plant)[1];
			
			System.out.println("Requesting Finished Good Count for "+finishedDate);
			
		    ZZPMONTZPRUECK1RFC request = new ZZPMONTZPRUECK1RFC();
		    request.setIMPAARBPL(workplaceCode);
		    request.setIMPAWERKS(plantCode);
		    request.setIMSODATUM(dateValue);
		    
		    ZZPMONTZPRUECK1RFCResponse response = (ZZPMONTZPRUECK1RFCResponse) soapConnector.callWebService(PRD_URI, request);
		    
	    	createFGBusDetails(response,workplaceCode,plantCode,finishedDateTime);
	    	
	    	System.out.println("Response for Finished Good on "+finishedDate+" - "+ response.getEXITCLAUF().getItem().size());
		}
	}
	
	private void createFGBusDetails(ZZPMONTZPRUECK1RFCResponse response, String workplaceCode, String plantCode, Timestamp finishedDateTime) throws ParseException {
		
		java.sql.Date sqlDate;
		
		int vehicleList = response.getEXITCLAUF().getItem().size();
		
		for(int i=0; i<vehicleList; i++) {
			
			String bbNumber = response.getEXITCLAUF().getItem().get(i).getBBSTUELI();
			System.out.println(bbNumber);
			if(bbNumber!=null && !bbNumber.equalsIgnoreCase("")) {
											    	
				String variantNumber = response.getEXITCLAUF().getItem().get(i).getGERNR();
				String assemblyType = response.getEXITCLAUF().getItem().get(i).getMAKTX();
				String customerName = response.getEXITCLAUF().getItem().get(i).getNAME1();
				String salesGroup = response.getEXITCLAUF().getItem().get(i).getVKGRP();
				String prodStartDate = response.getEXITCLAUF().getItem().get(i).getGSTRS();
				
				System.out.println(bbNumber+"-"+variantNumber+"-"+customerName);
			
			}
		}
    }
	
	private java.sql.Date setDateAndTime(String dateValue) throws ParseException {
        Date date;
        java.sql.Date sqlDate;
        date = new SimpleDateFormat("ddMMyyyy").parse(dateValue);
        sqlDate = new java.sql.Date(date.getTime());
        return sqlDate;
    }
}
