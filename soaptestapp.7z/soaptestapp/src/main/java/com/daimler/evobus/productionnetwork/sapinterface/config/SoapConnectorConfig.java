package com.daimler.evobus.productionnetwork.sapinterface.config;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import org.apache.http.auth.UsernamePasswordCredentials;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.security.wss4j2.Wss4jSecurityInterceptor;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import com.daimler.evobus.productionnetwork.sapinterface.service.SoapConnectorService;


@Configuration
public class SoapConnectorConfig {

	@Bean
	public Jaxb2Marshaller marshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		// this is the package name specified in the <generatePackage> specified in
		// pom.xml
		marshaller.setContextPath("com.daimler.evobus.productionnetwork.sapinterface.fgwsdlmodel");
		return marshaller;
	}

	@Bean
	public SoapConnectorService soapConnector(Jaxb2Marshaller marshaller) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		SoapConnectorService client = new SoapConnectorService();
		client.setDefaultUri("http://aevopjscs.bus.corpintra.net:50000/XISOAPAdapter/MessageServlet");
		client.setMarshaller(marshaller);
		client.setUnmarshaller(marshaller);
		client.setMessageSender(httpComponentsMessageSender());
//		ClientInterceptor[] interceptors = new ClientInterceptor[] {securityInterceptor()};
		ClientInterceptor[] interceptors =
		        new ClientInterceptor[] {new LogHttpHeaderClientInterceptor()};
		//Not mandatory
		client.setInterceptors(interceptors);
		return client;
	}
	
	@Bean
	public HttpComponentsMessageSender httpComponentsMessageSender() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		
	    HttpComponentsMessageSender httpComponentsMessageSender = new HttpComponentsMessageSender();
	    // set the basic authorization credentials
	    httpComponentsMessageSender.setCredentials(usernamePasswordCredentials());
	    httpComponentsMessageSender.setConnectionTimeout(600*1000);
	    httpComponentsMessageSender.setReadTimeout(600*1000);
	
	    return httpComponentsMessageSender;
	}
	
	@Bean
	public UsernamePasswordCredentials usernamePasswordCredentials() {
	    // pass the user name and password to be used
	    return new UsernamePasswordCredentials("TESTUSER", "P@$$W0RD");
	}
	
//  @Bean
//    public Wss4jSecurityInterceptor securityInterceptor() {
//       Wss4jSecurityInterceptor wss4jSecurityInterceptor = new Wss4jSecurityInterceptor();
//       wss4jSecurityInterceptor.setSecurementActions("UsernameToken");
//       wss4jSecurityInterceptor.setSecurementUsername("TESTUSER");
//       wss4jSecurityInterceptor.setSecurementPassword("P@$$W0RD");
//       wss4jSecurityInterceptor.setSecurementPasswordType("PasswordText");
//       wss4jSecurityInterceptor.setSecurementMustUnderstand(true);
//       wss4jSecurityInterceptor.setSecurementActor("");
////       wss4jSecurityInterceptor.setSecurementActions("urn:SOAPAction");
//       return wss4jSecurityInterceptor;
//   }
}
